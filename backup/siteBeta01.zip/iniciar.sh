#!/bin/bash
cd ~/Documentos/site/ && php -S 0.0.0.0:8080
